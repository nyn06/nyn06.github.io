﻿#include <iostream>
#include <cmath>
using namespace std;

struct Node 
{
    int info;
    int height;
    Node* pLeft;
    Node* pRight;
};

typedef Node* AVLTree;

// Hàm trả về chiều cao của một node
int getHeight(Node* node) 
{
    return (node == NULL) ? 0 : node->height;
}

// Tạo một node mới
Node* createNode(int x) 
{
    Node* p = new Node;
    p->info = x;
    p->height = 1;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Cập nhật chiều cao của node
void updateHeight(Node* node) 
{
    node->height = max(getHeight(node->pLeft), getHeight(node->pRight)) + 1;
}

// Hệ số cân bằng của node
int getBalance(Node* node) 
{
    return (node == NULL) ? 0 : getHeight(node->pLeft) - getHeight(node->pRight);
}

// Quay phải
Node* rotateRight(Node* y) 
{
    Node* x = y->pLeft;
    Node* T2 = x->pRight;
    x->pRight = y;
    y->pLeft = T2;
    updateHeight(y);
    updateHeight(x);
    return x;
}

// Quay trái
Node* rotateLeft(Node* x) 
{
    Node* y = x->pRight;
    Node* T2 = y->pLeft;
    y->pLeft = x;
    x->pRight = T2;
    updateHeight(x);
    updateHeight(y);
    return y;
}

// Thêm phần tử vào cây AVL
Node* insert(Node* root, int x) 
{
    if (root == NULL)
        return createNode(x);

    if (x < root->info)
        root->pLeft = insert(root->pLeft, x);
    else if (x > root->info)
        root->pRight = insert(root->pRight, x);
    else
        return root;  // Không cho phép trùng lặp

    updateHeight(root);
    int balance = getBalance(root);

    // Các trường hợp mất cân bằng
    if (balance > 1 && x < root->pLeft->info) // Left Left
        return rotateRight(root);
    if (balance < -1 && x > root->pRight->info) // Right Right
        return rotateLeft(root);
    if (balance > 1 && x > root->pLeft->info) 
    { // Left Right
        root->pLeft = rotateLeft(root->pLeft);
        return rotateRight(root);
    }
    if (balance < -1 && x < root->pRight->info) 
    { // Right Left
        root->pRight = rotateRight(root->pRight);
        return rotateLeft(root);
    }
    return root;
}

// Hàm tìm phần tử nhỏ nhất
Node* minValueNode(Node* node) 
{
    Node* current = node;
    while (current->pLeft != NULL)
        current = current->pLeft;
    return current;
}

// Xóa phần tử khỏi cây AVL
Node* deleteNode(Node* root, int x) 
{
    if (root == NULL)
        return root;

    if (x < root->info)
        root->pLeft = deleteNode(root->pLeft, x);
    else if (x > root->info)
        root->pRight = deleteNode(root->pRight, x);
    else {
        if ((root->pLeft == NULL) || (root->pRight == NULL)) 
        {
            Node* temp = root->pLeft ? root->pLeft : root->pRight;
            if (temp == NULL) 
            {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp;
            delete temp;
        }
        else 
        {
            Node* temp = minValueNode(root->pRight);
            root->info = temp->info;
            root->pRight = deleteNode(root->pRight, temp->info);
        }
    }
    if (root == NULL)
        return root;

    updateHeight(root);
    int balance = getBalance(root);

    if (balance > 1 && getBalance(root->pLeft) >= 0) // Left Left
        return rotateRight(root);
    if (balance > 1 && getBalance(root->pLeft) < 0) 
    { // Left Right
        root->pLeft = rotateLeft(root->pLeft);
        return rotateRight(root);
    }
    if (balance < -1 && getBalance(root->pRight) <= 0) // Right Right
        return rotateLeft(root);
    if (balance < -1 && getBalance(root->pRight) > 0) 
    { // Right Left
        root->pRight = rotateRight(root->pRight);
        return rotateLeft(root);
    }
    return root;
}

// Duyệt LNR (Inorder)
void inorder(Node* root) 
{
    if (root != NULL) {
        inorder(root->pLeft);
        cout << root->info << " ";
        inorder(root->pRight);
    }
}

// Hàm test
void test() 
{
    AVLTree root = NULL;
    int arr[] = { 10, 20, 30, 40, 50, 25 };
    int n = sizeof(arr) / sizeof(arr[0]);
    for (int i = 0; i < n; i++)
        root = insert(root, arr[i]);

    cout << "Cay AVL sau khi them: ";
    inorder(root);
    cout << endl;

    root = deleteNode(root, 30);
    cout << "Cay AVL sau khi xoa 30: ";
    inorder(root);
    cout << endl;
}

int main() 
{
    test();
    return 0;
}
