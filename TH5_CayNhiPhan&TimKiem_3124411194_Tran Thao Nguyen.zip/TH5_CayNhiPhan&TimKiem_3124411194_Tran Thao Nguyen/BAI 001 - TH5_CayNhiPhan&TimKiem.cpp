﻿#include <iostream>
#include <cmath>
using namespace std;
struct node
{
	int info;
	struct node* pLeft;
	struct node* pRight;
};
typedef struct node NODE;
typedef NODE*TREE;

// Khởi tạo cây
void KhoiTao(TREE& Root) 
{
	Root = NULL;
}

// Thêm một nút vào cây
void ThemNode(TREE& Root, int x) 
{
	if (Root == NULL) {
		Root = new NODE;
		Root->info = x;
		Root->pLeft = Root->pRight = NULL;
	}
	else {
		if (x < Root->info)
			ThemNode(Root->pLeft, x);
		else
			ThemNode(Root->pRight, x);
	}
}
// Duyệt cây theo thứ tự LNR (trái - gốc - phải)
void DuyetLNR(TREE Root) 
{
	if (Root != NULL) {
		DuyetLNR(Root->pLeft);
		cout << Root->info << " ";
		DuyetLNR(Root->pRight);
	}
}
// câu a) Viết chương trình tính trung bình cộng các nút trong cây
int DemNode(TREE Root)
{
	if (Root == NULL)
		return 0;
	int a = DemNode(Root->pLeft);
	int b = DemNode(Root->pRight);
	return (a + b + 1);
}
int TongNode(TREE Root)
{
	if (Root == NULL)
		return 0;
	int a = TongNode(Root->pLeft);
	int b = TongNode(Root->pRight);
	return (a + b + Root->info);
}
float TrungBinhCong(TREE Root)
{
	int s = TongNode(Root);
	int dem = DemNode(Root);
	if (dem == 0)
		return 0;
	return (float)s / dem;
}
// câu b) Viết chương trình tính trung bình cộng các nút dương trong cây
int DemDuong(TREE Root)
{
	if (Root == NULL)
		return 0;
	int a = DemDuong(Root->pLeft);
	int b = DemDuong(Root->pRight);
	if (Root->info > 0)
		return (a + b + 1);
	return (a + b);
}
int TongDuong(TREE Root)
{
	if (Root == NULL)
		return 0;
	int a = TongDuong(Root->pLeft);
	int b = TongDuong(Root->pRight);
	if (Root->info > 0)
		return (a + b + Root->info);
	return (a + b);
}
float TrungBinhDuong(TREE Root)
{
	int s = TongDuong(Root);
	int dem = DemDuong(Root);
	if (dem == 0)
		return 0;
	return (float)s / dem;
}
// câu c) Viết chương trình tính trung bình cộng các nút âm trong cây
int DemAm(TREE Root)
{
	if (Root == NULL)
		return 0;
	int a = DemAm(Root->pLeft);
	int b = DemAm(Root->pRight);
	if (Root->info < 0)
		return (a + b + 1);
	return (a + b);
}
int TongAm(TREE Root)
{
	if (Root == NULL)
		return 0;
	int a = TongAm(Root->pLeft);
	int b = TongAm(Root->pRight);
	if (Root->info < 0)
		return (a + b + Root->info);
	return (a + b);
}
float TrungBinhCongAm(TREE Root)
{
	int s = TongAm(Root);
	int dem = DemAm(Root);
	if (dem == 0)
		return 0;
	return (float)s / dem;
}
// câu d) Viết chương trình tính tính tỉ số R=a/b. Với a là tổng các nút có giá trị dương, b là tổng các nút có giá trị âm
float TinhTySo(TREE Root)
{
	int a = TongDuong(Root);
	int b = TongAm(Root);
	if (b == 0)
	   return 0;
	return (float)a / b;
}
// TEST1: Kiểm tra trung bình cộng tất cả các nút
void test1(TREE Root) 
{
	cout << "Trung binh cong cac nut trong cay: " << TrungBinhCong(Root) << endl;
}

// TEST2: Kiểm tra trung bình cộng các số dương
void test2(TREE Root) 
{
	cout << "Trung binh cong cac nut duong: " << TrungBinhDuong(Root) << endl;
}

// TEST3: Kiểm tra trung bình cộng các số âm
void test3(TREE Root) 
{
	cout << "Trung binh cong cac nut am: " << TrungBinhCongAm(Root) << endl;
}

// TEST4: Kiểm tra tỷ số R = a / b
void test4(TREE Root) 
{
	cout << "Ty so R = TongDuong / TongAm: " << TinhTySo(Root) << endl;
}

// Hàm chạy tất cả test
void test() 
{
	TREE Root;
	KhoiTao(Root);

	cout << "Nhap so luong node: ";
	int n, x;
	cin >> n;

	cout << "Nhap " << n << " so nguyen: ";
	for (int i = 0; i < n; i++) {
		cin >> x;
		ThemNode(Root, x);
	}

	cout << "Cay theo thu tu LNR: ";
	DuyetLNR(Root);
	cout << endl;

	test1(Root);
	test2(Root);
	test3(Root);
	test4(Root);
}

// Chương trình chính
int main() 
{
	test();
	return 0;
}