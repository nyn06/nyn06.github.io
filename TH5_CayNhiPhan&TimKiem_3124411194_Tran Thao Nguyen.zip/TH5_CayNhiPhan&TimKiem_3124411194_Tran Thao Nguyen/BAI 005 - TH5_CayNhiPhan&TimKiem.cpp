﻿#include <iostream>
#include <cmath>
using namespace std;

struct Node 
{
    int info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;
// Hàm khởi tạo cây
void KhoiTao(TREE& Root) 
{
    Root = NULL;
}
// Hàm tạo một node mới
Node* TaoNode(int x) 
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
// Hàm thêm một node vào cây nhị phân tìm kiếm
void ThemNode(TREE& Root, int x) 
{
    if (Root == NULL) 
    {
        Root = TaoNode(x);
    }
    else 
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}

// Hàm duyệt cây theo thứ tự NLR để kiểm tra
void DuyetNLR(TREE Root) 
{
    if (Root != NULL) 
    {
        cout << Root->info << " ";
        DuyetNLR(Root->pLeft);
        DuyetNLR(Root->pRight);
    }
}

// Hàm đếm số nút có đúng một nhánh con (NLR)
int DemNutMotCon(TREE Root) 
{
    if (Root == NULL)
        return 0;

    int dem = 0;
    if ((Root->pLeft == NULL && Root->pRight != NULL) || (Root->pLeft != NULL && Root->pRight == NULL)) 
    {
        dem = 1;
    }

    return dem + DemNutMotCon(Root->pLeft) + DemNutMotCon(Root->pRight);
}

// Hàm test
void test() 
{
    TREE Root;
    KhoiTao(Root);

    // Xây dựng cây từ danh sách {10, 5, 15, 3, 9, 12, 18, 7, 20}
    int arr[] = { 10, 5, 15, 3, 9, 12, 18, 7, 20 };
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }

    // In cây để kiểm tra
    cout << "Duyet NLR: ";
    DuyetNLR(Root);
    cout << endl;

    // Đếm số nút có một con
    int ketQua = DemNutMotCon(Root);
    cout << "So nut co dung mot con trong cay: " << ketQua << endl;
}

// Hàm main
int main() 
{
    test();
    return 0;
}
