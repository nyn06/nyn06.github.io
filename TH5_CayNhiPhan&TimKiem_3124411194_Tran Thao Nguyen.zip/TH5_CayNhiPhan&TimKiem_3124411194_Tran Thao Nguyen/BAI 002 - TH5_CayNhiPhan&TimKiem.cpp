﻿#include <iostream>
#include <cmath>
using namespace std;

struct Node
{
    int info;
    Node* pLeft;
    Node* pRight;
};

typedef Node* TREE;

// Khởi tạo cây
void KhoiTao(TREE& Root)
{
    Root = NULL;
}

// Hàm tạo một node mới
Node* TaoNode(int x)
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Hàm thêm node vào cây BST
void ThemNode(TREE& Root, int x)
{
    if (Root == NULL)
    {
        Root = TaoNode(x);
    }
    else
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}

// Hàm xoay trái tại nút P
void XoayTrai(TREE& Root)
{
    if (Root == NULL || Root->pRight == NULL)
        return;

    TREE newRoot = Root->pRight;
    Root->pRight = newRoot->pLeft;
    newRoot->pLeft = Root;
    Root = newRoot;
}

// Duyệt cây theo thứ tự LNR
void DuyetLNR(TREE Root)
{
    if (Root != NULL) 
    {
        DuyetLNR(Root->pLeft);
        cout << Root->info << " ";
        DuyetLNR(Root->pRight);
    }
}

// Hàm test: Xây dựng cây và thực hiện xoay trái
void test() 
{
    TREE Root;
    KhoiTao(Root);

    // Xây dựng cây từ Hình 1
    int arr[] = { 10, 5, 3, 7, 9, 15, 12, 18, 20 };
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }

    cout << "Cay truoc khi xoay trai (LNR): ";
    DuyetLNR(Root);
    cout << endl;

    // Thực hiện xoay trái tại nút 10
    XoayTrai(Root);

    cout << "Cay sau khi xoay trai (LNR): ";
    DuyetLNR(Root);
    cout << endl;
}
int main() 
{
    test();
    return 0;
}
