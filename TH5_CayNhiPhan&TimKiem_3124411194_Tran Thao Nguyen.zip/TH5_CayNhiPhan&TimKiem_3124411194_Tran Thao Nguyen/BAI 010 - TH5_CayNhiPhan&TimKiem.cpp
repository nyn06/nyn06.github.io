﻿#include <iostream>
#include <fstream>
using namespace std;
struct Node 
{
    float info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;
// Hàm khởi tạo cây
void KhoiTao(TREE& Root) 
{
    Root = NULL;
}

// Hàm tạo một node mới
Node* TaoNode(float x) 
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Hàm thêm một node vào cây nhị phân tìm kiếm
void ThemNode(TREE& Root, float x) 
{
    if (Root == NULL) 
    {
        Root = TaoNode(x);
    }
    else 
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}

// Hàm duyệt cây theo thứ tự LRN và ghi vào file nhị phân
void LRN(TREE t, FILE* fp) 
{
    if (t == NULL) return;
    LRN(t->pLeft, fp);
    LRN(t->pRight, fp);
    fwrite(&t->info, sizeof(float), 1, fp);
}

// Hàm xuất cây ra file nhị phân
int Xuat(const char* filename, TREE t) 
{
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL) return 0;
    LRN(t, fp);
    fclose(fp);
    return 1;
}

// Hàm đọc file và hiển thị nội dung
void DocFile(const char* filename) 
{
    FILE* fp = fopen(filename, "rb");
    if (fp == NULL) 
    {
        cout << "Khong the mo file!\n";
        return;
    }

    float num;
    cout << "Noi dung file: ";
    while (fread(&num, sizeof(float), 1, fp)) 
    {
        cout << num << " ";
    }
    cout << endl;
    fclose(fp);
}

// Hàm test: Xây dựng cây và kiểm tra chức năng ghi và đọc file
void test() 
{
    TREE Root;
    KhoiTao(Root);

    // Danh sách số thực để tạo cây
    float arr[] = { 10.5, 5.2, 15.8, 3.1, 9.7, 12.3, 18.9, 7.4, 20.6 };
    int n = sizeof(arr) / sizeof(arr[0]);

    // Thêm từng phần tử vào cây
    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }

    // Xuất cây ra file nhị phân
    if (Xuat("data.out", Root)) 
    {
        cout << "Da ghi du lieu vao file data.out\n";
    }
    else 
    {
        cout << "Loi khi ghi file\n";
    }

    // Đọc lại file để kiểm tra nội dung
    DocFile("data.out");
}

int main() 
{
    test();
    return 0;
}
