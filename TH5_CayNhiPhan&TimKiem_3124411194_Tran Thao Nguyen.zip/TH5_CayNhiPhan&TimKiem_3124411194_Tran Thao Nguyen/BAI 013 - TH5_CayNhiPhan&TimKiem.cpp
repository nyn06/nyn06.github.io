﻿#include <iostream>
#include <fstream>
using namespace std;

struct Node 
{
    float info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;
// Khởi tạo cây
void KhoiTao(TREE& Root) 
{
    Root = NULL;
}
// Tạo node mới
Node* TaoNode(float x) 
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Thêm node vào cây nhị phân tìm kiếm
void ThemNode(TREE& Root, float x) 
{
    if (Root == NULL) 
    {
        Root = TaoNode(x);
    }
    else {
        if (x < Root->info) 
        {
            ThemNode(Root->pLeft, x);
        }
        else 
        {
            ThemNode(Root->pRight, x);
        }
    }
}

// Duyệt NLR và ghi vào tập tin
void NLR_Ghi(TREE t, ofstream& file) 
{
    if (t == NULL) return;
    file.write(reinterpret_cast<char*>(&t->info), sizeof(float));
    NLR_Ghi(t->pLeft, file);
    NLR_Ghi(t->pRight, file);
}

// Xuất cây ra tập tin
bool Xuat(char* filename, TREE t) 
{
    ofstream file(filename, ios::binary);
    if (!file) return false;
    NLR_Ghi(t, file);
    file.close();
    return true;
}

// Đọc dữ liệu từ file và tái tạo cây
bool DocVaKhoiPhuc(char* filename, TREE& Root) 
{
    ifstream file(filename, ios::binary);
    if (!file) return false;
    float x;
    while (file.read(reinterpret_cast<char*>(&x), sizeof(float))) 
    {
        ThemNode(Root, x);
    }
    file.close();
    return true;
}

// Kiểm tra bằng cách duyệt LNR
void LNR(TREE t) 
{
    if (t == NULL) return;
    LNR(t->pLeft);
    cout << t->info << " ";
    LNR(t->pRight);
}

// Hàm test
void test() 
{
    TREE Root;
    KhoiTao(Root);
    float arr[] = { 10.5, 5.2, 15.8, 3.1, 9.6, 12.4, 18.7, 7.3, 20.9 };
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }

    // Xuất cây ra tập tin
    char filename[] = "data.out";
    if (Xuat(filename, Root)) 
    {
        cout << "Da ghi cay vao file.\n";
    }

    // Tạo cây mới từ file
    TREE NewTree;
    KhoiTao(NewTree);
    if (DocVaKhoiPhuc(filename, NewTree)) 
    {
        cout << "Cay doc tu file: ";
        LNR(NewTree);
        cout << endl;
    }
}

int main() 
{
    test();
    return 0;
}
