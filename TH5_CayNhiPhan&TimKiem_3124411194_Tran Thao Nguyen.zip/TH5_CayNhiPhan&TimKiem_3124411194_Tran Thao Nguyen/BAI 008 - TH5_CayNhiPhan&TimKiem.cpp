﻿#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
struct Node 
{
    float info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;

// Hàm khởi tạo cây
void KhoiTao(TREE& Root) 
{
    Root = NULL;
}
// Hàm tạo một node mới
Node* TaoNode(float x) 
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Hàm thêm một node vào cây nhị phân tìm kiếm
void ThemNode(TREE& Root, float x) 
{
    if (Root == NULL) 
    {
        Root = TaoNode(x);
    }
    else 
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}

// Hàm duyệt LNR và ghi dữ liệu vào file nhị phân
void LNR(TREE t, FILE* fp) 
{
    if (t == NULL)
        return;
    LNR(t->pLeft, fp);
    fwrite(&t->info, sizeof(float), 1, fp);
    LNR(t->pRight, fp);
}

// Hàm xuất cây ra file nhị phân
int Xuat(const char* filename, TREE t) 
{
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    LNR(t, fp);
    fclose(fp);
    return 1;
}

// Hàm đọc và hiển thị nội dung file nhị phân
void DocFile(const char* filename) 
{
    FILE* fp = fopen(filename, "rb");
    if (fp == NULL) 
    {
        cout << "Khong the mo file!" << endl;
        return;
    }

    float x;
    cout << "Cac so trong file: ";
    while (fread(&x, sizeof(float), 1, fp)) 
    {
        cout << x << " ";
    }
    cout << endl;
    fclose(fp);
}

// Hàm test
void test() 
{
    TREE Root;
    KhoiTao(Root);

    // Tạo cây từ danh sách số thực
    float arr[] = { 10.5, 5.2, 15.8, 3.1, 9.7, 12.3, 18.9, 7.4, 20.6 };
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }

    // Xuất cây ra file
    const char* filename = "data.out";
    if (Xuat(filename, Root)) 
    {
        cout << "Da ghi du lieu vao file " << filename << endl;
    }
    else 
    {
        cout << "Loi khi ghi file!" << endl;
    }

    // Đọc file để kiểm tra
    DocFile(filename);
}

// Hàm main
int main() 
{
    test();
    return 0;
}
