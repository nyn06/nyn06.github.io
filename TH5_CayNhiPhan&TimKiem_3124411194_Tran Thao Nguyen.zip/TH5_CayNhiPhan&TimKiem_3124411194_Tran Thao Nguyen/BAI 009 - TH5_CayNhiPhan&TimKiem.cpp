﻿#include <iostream>
#include <cstdio>
using namespace std;
struct Node 
{
    float info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;
// Hàm khởi tạo cây
void KhoiTao(TREE& Root) 
{
    Root = NULL;
}
// Hàm tạo một node mới
Node* TaoNode(float x) 
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
// Hàm thêm một node vào cây nhị phân tìm kiếm
void ThemNode(TREE& Root, float x) 
{
    if (Root == NULL) 
    {
        Root = TaoNode(x);
    }
    else 
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}
// Hàm duyệt NLR và ghi dữ liệu vào file nhị phân
void NLR(TREE t, FILE* fp) 
{
    if (t == NULL)
        return;
    fwrite(&t->info, sizeof(float), 1, fp); // Ghi nút gốc
    NLR(t->pLeft, fp);  // Duyệt cây con trái
    NLR(t->pRight, fp); // Duyệt cây con phải
}

// Hàm xuất cây ra file nhị phân
int Xuat(const char* filename, TREE t) 
{
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    NLR(t, fp);
    fclose(fp);
    return 1;
}
// Hàm đọc file và in nội dung kiểm tra
void DocFile(const char* filename) 
{
    FILE* fp = fopen(filename, "rb");
    if (fp == NULL) 
    {
        cout << "Loi mo file!" << endl;
        return;
    }
    float x;
    cout << "Noi dung file (NLR): ";
    while (fread(&x, sizeof(float), 1, fp)) 
    {
        cout << x << " ";
    }
    cout << endl;
    fclose(fp);
}
// Hàm test
void test() 
{
    TREE Root;
    KhoiTao(Root);
    float arr[] = { 10.5, 5.2, 15.8, 3.1, 9.7, 12.3, 18.9, 7.4, 20.6 };
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }
    // Xuất cây ra file
    const char* filename = "data.out";
    if (Xuat(filename, Root)) 
    {
        cout << "Da ghi du lieu vao file " << filename << " thanh cong.\n";
    }
    else 
    {
        cout << "Loi khi ghi file!\n";
    }

    // Đọc lại file để kiểm tra
    DocFile(filename);
}

int main() 
{
    test();
    return 0;
}
