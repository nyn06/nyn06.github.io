﻿#include <iostream>
#include <cmath>
using namespace std;

struct Node 
{
    int info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;
void KhoiTao(TREE& Root) 
{
    Root = NULL;
}
// Tạo một nút mới
Node* TaoNode(int x) 
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
// Thêm một nút vào cây BST
void ThemNode(TREE& Root, int x) 
{
    if (Root == NULL) 
    {
        Root = TaoNode(x);
    }
    else 
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}
// Tìm nút nhỏ nhất trong cây
Node* NhoNhat(TREE Root) 
{
    if (Root == NULL)
        return NULL;
    while (Root->pLeft)
        Root = Root->pLeft;
    return Root;
}

// Tìm nút lớn nhất trong cây
Node* LonNhat(TREE Root) 
{
    if (Root == NULL)
        return NULL;
    while (Root->pRight)
        Root = Root->pRight;
    return Root;
}
void test() 
{
    TREE Root;
    KhoiTao(Root);

    // Danh sách phần tử để tạo BST
    int arr[] = { 10, 5, 15, 3, 9, 12, 18, 7, 20 };
    int n = sizeof(arr) / sizeof(arr[0]);

    // Thêm các phần tử vào cây
    for (int i = 0; i < n; i++) 
    {
        ThemNode(Root, arr[i]);
    }

    // Tìm nút nhỏ nhất và lớn nhất
    Node* minNode = NhoNhat(Root);
    Node* maxNode = LonNhat(Root);

    if (minNode) cout << "Phan tu nho nhat: " << minNode->info << endl;
    if (maxNode) cout << "Phan tu lon nhat: " << maxNode->info << endl;
}
int main() 
{
    test();
    return 0;
}
