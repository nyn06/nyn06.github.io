﻿#include <iostream>
#include <cmath>
using namespace std;

struct Node
{
    int info;
    Node* pLeft;
    Node* pRight;
};
typedef Node* TREE;
// Hàm khởi tạo cây
void KhoiTao(TREE& Root)
{
    Root = NULL;
}
// Hàm tạo một node mới
Node* TaoNode(int x)
{
    Node* p = new Node;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Hàm thêm một node vào cây nhị phân tìm kiếm
void ThemNode(TREE& Root, int x)
{
    if (Root == NULL)
    {
        Root = TaoNode(x);
    }
    else
    {
        if (x < Root->info)
            ThemNode(Root->pLeft, x);
        else
            ThemNode(Root->pRight, x);
    }
}

// Hàm đếm số nút trong cây BST (Dùng đệ quy)
int SoNut(TREE Root)
{
    if (Root == NULL)
        return 0;
    return 1 + SoNut(Root->pLeft) + SoNut(Root->pRight);
}

// Hàm tính tổng giá trị các nút trong cây BST (Dùng đệ quy)
int TongGiaTri(TREE Root)
{
    if (Root == NULL)
        return 0;
    return Root->info + TongGiaTri(Root->pLeft) + TongGiaTri(Root->pRight);
}

// Hàm test: Xây dựng cây và kiểm tra số nút, tổng giá trị các nút
void test()
{
    TREE Root;
    KhoiTao(Root);

    // Xây dựng cây từ danh sách {10, 5, 15, 3, 9, 12, 18, 7, 20}
    int arr[] = { 10, 5, 15, 3, 9, 12, 18, 7, 20 };
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++)
    {
        ThemNode(Root, arr[i]);
    }

    // Đếm số nút trong cây
    int soNut = SoNut(Root);
    cout << "So nut trong cay: " << soNut << endl;

    // Tính tổng giá trị các nút trong cây
    int tongGiaTri = TongGiaTri(Root);
    cout << "Tong gia tri cac nut trong cay: " << tongGiaTri << endl;
}

// Hàm main
int main()
{
    test();
    return 0;
}
