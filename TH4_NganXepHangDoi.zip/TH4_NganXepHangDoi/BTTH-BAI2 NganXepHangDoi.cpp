﻿#include <iostream>
#include <cmath>
using namespace std;
typedef struct
{
    int dau, cuoi, kichThuoc;
    int* mang;
}HangDoi;

void KhoiTao(HangDoi& q, int kichThuoc)
{
    q.kichThuoc = kichThuoc;
    q.dau = q.cuoi = -1;
    q.mang = new int[kichThuoc];
}

// Kiểm tra hàng đợi rỗng
bool Rong(HangDoi& q)
{
    return q.dau == -1;
}

// Kiểm tra hàng đợi đầy
bool Day(HangDoi& q)
{
    return (q.cuoi + 1) % q.kichThuoc == q.dau;
}

// Thêm phần tử vào hàng đợi
void Them(HangDoi& q, int x)
{
    if (!Day(q))
    {
        if (Rong(q)) q.dau = 0;
        q.cuoi = (q.cuoi + 1) % q.kichThuoc;
        q.mang[q.cuoi] = x;
    }
    else
        cout << "Hang doi da day!\n";
}

// Lấy phần tử khỏi hàng đợi
int Xoa(HangDoi& q)
{
    if (!Rong(q))
    {
        int x = q.mang[q.dau];
        if (q.dau == q.cuoi) q.dau = q.cuoi = -1;
        else q.dau = (q.dau + 1) % q.kichThuoc;
        return x;
    }
    return -1;
}

// Xem phần tử đầu tiên
int XemDau(HangDoi& q)
{
    return Rong(q) ? -1 : q.mang[q.dau];
}

// Xóa toàn bộ hàng đợi
void XoaHet(HangDoi& q)
{
    q.dau = q.cuoi = -1;
}
int SoLuongPhanTu(HangDoi& q)
{
    if (Rong(q)) return 0;
    if (q.cuoi >= q.dau) return q.cuoi - q.dau + 1;
    return q.kichThuoc - (q.dau - q.cuoi - 1);
}
void test1()
{
    cout << "-----TEST1-----\n";
    // Bài toán xếp lịch
    HangDoi nam, nu;
    KhoiTao(nam, 10);
    KhoiTao(nu, 10);

    // Giả lập danh sách nam và nữ
    Them(nam, 1); Them(nam, 2); Them(nam, 3);
    Them(nu, 1); Them(nu, 2);

    cout << "Danh sach cap mua:\n";
    while (!Rong(nam) && !Rong(nu))
    {
        cout << "Cap: Nam " << Xoa(nam) << " - Nu " << Xoa(nu) << endl;
    }

    // Kiểm tra còn ai chưa có cặp
    if (!Rong(nam)) cout << "Con " << SoLuongPhanTu(nam) << " nam chua co cap.\n";
    if (!Rong(nu)) cout << "Con " << SoLuongPhanTu(nu) << " nu chua co cap.\n";
}
// Hàm RadixSort
void RadixSort(int a[], int n)
{
    const int BASE = 10;
    HangDoi hang[BASE];

    for (int i = 0; i < BASE; i++) KhoiTao(hang[i], n);

    // Tìm số lớn nhất để xác định số chữ số cần xét
    int max = a[0];
    for (int i = 1; i < n; i++)
    {
        if (a[i] > max) max = a[i];
    }

    // Lần lượt xét từng chữ số
    for (int x = 1; max / x > 0; x *= BASE)
    {
        for (int i = 0; i < n; i++) {
            int digit = (a[i] / x) % BASE;
            Them(hang[digit], a[i]);
        }

        // Gom lại các phần tử từ hàng đợi
        int index = 0;
        for (int i = 0; i < BASE; i++)
        {
            while (!Rong(hang[i]))
            {
                a[index++] = Xoa(hang[i]);
            }
        }
    }
}

// Hàm kiểm tra Radix Sort
void test2()
{
    cout << "-----TEST2-----\n";
    int a[] = { 170, 45, 75, 90, 802, 24, 2, 66 };
    int n = sizeof(a) / sizeof(a[0]);

    cout << "Mang truoc khi sap xep:\n";
    for (int i = 0; i < n; i++) cout << a[i] << " ";
    cout << endl;

    RadixSort(a, n);

    cout << "Mang sau khi sap xep:\n";
    for (int i = 0; i < n; i++) cout << a[i] << " ";
    cout << endl;
}

int main()
{
    test1();
    test2();
    return 0;
}
