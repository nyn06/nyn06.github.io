﻿#include <iostream>
#include <cmath>
using namespace std;
typedef struct
{
    int top;
    int size;
    int* arr;
}Stack;

void KhoiTao(Stack& s, int size)
{
    s.top = -1;
    s.size = size;
    s.arr = new int[size];
}

bool Rong(Stack& s)
{
    return s.top == -1;
}

bool Day(Stack& s)
{
    return s.top == s.size - 1;
}

void Them(Stack& s, int x)
{
    if (!Day(s))
    {
        s.arr[++s.top] = x;
    }
}

int Xoa(Stack& s)
{
    return Rong(s) ? -1 : s.arr[s.top--];
}

// (a) Tính số Fibonacci khử đệ quy
int Fibonacci(int n)
{
    if (n == 0) return 0;
    if (n == 1) return 1;

    Stack s;
    KhoiTao(s, n);
    Them(s, 0);
    Them(s, 1);

    for (int i = 2; i <= n; i++)
    {
        int a = Xoa(s);
        int b = Xoa(s);
        Them(s, a);
        Them(s, a + b);
    }
    return Xoa(s);
}

void test1()
{
    cout << "-----TEST1-----\n";
    int n;
    cout << "Nhap so Fibonacci muon tinh: ";
    cin >> n;
    cout << "Fibonacci(" << n << ") = " << Fibonacci(n) << endl;
}

// (b) Đảo ngược số bằng stack (giữ số 0 ở cuối)
string DaoNguocSo(string n)
{
    Stack s;
    KhoiTao(s, n.length());

    for (char c : n)
    {
        Them(s, c); // Đẩy từng chữ số vào stack
    }

    string dao = "";
    while (!Rong(s))
    {
        dao += Xoa(s); // Lấy ra từng ký tự
    }

    return dao;
}

void test2()
{
    cout << "-----TEST2-----\n";
    string n;
    cout << "Nhap so muon dao nguoc: ";
    cin >> n;
    cout << "So dao nguoc: " << DaoNguocSo(n) << endl;
}
void Hanoi(int n, int from, int to, int aux)
{
    Stack s;
    KhoiTao(s, n * 4); // Stack đủ lớn

    // Đẩy bước đầu tiên vào stack
    Them(s, n);
    Them(s, from);
    Them(s, to);
    Them(s, aux);

    while (!Rong(s))
    {
        // Lấy dữ liệu từ stack
        int temp_aux = Xoa(s);
        int temp_to = Xoa(s);
        int temp_from = Xoa(s);
        int temp_n = Xoa(s);

        if (temp_n == 1)
        {
            cout << "Di chuyen dia 1 tu " << temp_from << " den " << temp_to << endl;
        }
        else
        {
            // Bước 1: Đẩy n-1 đĩa từ from → aux, dùng to làm trung gian
            Them(s, temp_n - 1);
            Them(s, temp_from);
            Them(s, temp_aux);
            Them(s, temp_to);

            // Bước 2: Di chuyển đĩa lớn nhất từ from → to (IN RA LUÔN)
            cout << "Di chuyen dia " << temp_n << " tu " << temp_from << " den " << temp_to << endl;

            // Bước 3: Đẩy n-1 đĩa từ aux → to, dùng from làm trung gian
            Them(s, temp_n - 1);
            Them(s, temp_aux);
            Them(s, temp_to);
            Them(s, temp_from);
        }
    }
}

void test3()
{
    cout << "-----TEST3-----\n";
    int n;
    cout << "Nhap so dia: ";
    cin >> n;
    Hanoi(n, 1, 3, 2);
}

int main()
{
    test1();
    test2();
    test3();
    return 0;
}
