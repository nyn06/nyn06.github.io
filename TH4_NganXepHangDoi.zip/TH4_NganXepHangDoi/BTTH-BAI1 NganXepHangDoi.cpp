﻿#include <iostream>
#include <cmath>
using namespace std;

typedef struct  
{
    int top; // Đỉnh ngăn xếp
    int count; // Số phần tử 
    int size; // Kích thước tối đa
    int* arr; // Chứa dữ liệu
} Stack; 

void InitStack(Stack& s, int size) 
{
    s.top = -1;
    s.count = 0;
    s.size = size;
    s.arr = new int[s.size];
}

bool IsEmpty(Stack& s) 
{
    // Kiểm tra chồng rỗng 
    return s.top == -1;
}

bool IsFull(Stack& s) 
{
    // Kiểm tra chồng bị đầy 
    return s.top == s.size - 1;
}

void PushStack(Stack& s, int x) 
{
    // Thêm x vào stack 
    if (!IsFull(s))
    {
        s.top++;
        s.arr[s.top] = x;
        s.count++;
    }
    else
        cout << "Stack bi tran";
}

int PopStack(Stack& s) 
{
    // Lấy x ra khỏi stack 
    if (!IsEmpty(s)) 
    {
        int x = s.arr[s.top];
        s.top--;
        s.count--;
        return x;
    }
    return -1; // Stack rỗng 
}

int PeekStack(Stack& s)
{
    // Xem đỉnh Stack
    if (!IsEmpty(s)) 
    {
        return s.arr[s.top];
    }
    return -1; // Chồng rỗng
}

void Clear(Stack& s) 
{
    // Xóa bỏ Stack, kết quả là Stack rỗng
    s.top = -1;
    s.count = 0;
}

void test1()
{
    // Đảo số
    cout << "-----Test 1-----\n";
    char so[100];  // Dùng mảng ký tự 
    cout << "Nhap so can dao: ";
    cin >> so; // Nhập dạng chuỗi

    Stack s;
    InitStack(s, 100); // Kích thước lớn hơn để chứa số dài

    int i = 0;
    while (so[i] != '\0') // Duyệt từng ký tự số
    {
        PushStack(s, so[i]);
        i++;
    }

    cout << "So dao nguoc: ";
    while (!IsEmpty(s))
    {
        cout << char(PopStack(s)); // Ép kiểu lại thành char
    }
    cout << endl;
}


void test2() 
{
    cout << "-----Test 2-----\n";
    char str[1000000]; // Mảng ký tự thay vì string
    cout << "Nhap xau: ";
    cin.ignore();
    cin.getline(str, 1000000);
    Stack s;
    InitStack(s,strlen(str));

    // Đưa từng ký tự vào Stack 
    int i = 0;
    while (str[i] != '\0') 
    {
        PushStack(s, str[i]);
        i++;
    }

    // So sánh ký tự trong Stack với chuỗi gốc 
    i = 0;
    bool xaudoixung = true;
    while (str[i] != '\0') 
    {
        if (str[i] != PopStack(s)) 
        {
            xaudoixung = false;
            break;
        }
        i++;
    }
    // In kết quả
    if (xaudoixung)
        cout << "Xau doi xung\n";
    else 
        cout << "Xau khong doi xung\n";
}

void test3() 
{ 
    // Đổi số thập phân sang nhị phân
    cout << "-----Test 3-----\n";
    int so;
    cout << "Nhap so thap phan: ";
    cin >> so;
    Stack s;
    InitStack(s, 20);
    while (so > 0) 
    {
        PushStack(s, so % 2);
        so /= 2;
    }
    cout << "So nhi phan: ";
    while (!IsEmpty(s)) 
        cout << PopStack(s);
    cout << endl;
}
int uutien(char toantu) {
    if (toantu == '+' || toantu == '-') return 1;
    if (toantu == '*' || toantu == '/') return 2;
    return 0;
}

void test4() 
{
    // Dạng Hậu Tố
    cout << "-----Test 4-----\n";
    char trungto[100];
    cout << "Nhap bieu thuc trung to: ";
    cin.ignore();
    cin.getline(trungto, 100);

    Stack nganxep;
    InitStack(nganxep, 100);
    char hauto[100] = "";
    int j = 0;

    for (int i = 0; trungto[i] != '\0'; i++)
    {
        char kytu = trungto[i];
        if (kytu >= '0' && kytu <= '9')  
        {
            hauto[j] = kytu;
            j++;
        }
        else if (kytu == '(')
        {
            PushStack(nganxep, kytu);
        }
        else if (kytu == ')')
        {
            while (!IsEmpty(nganxep) && PeekStack(nganxep) != '(')
            {
                hauto[j++] = PopStack(nganxep);
            }
            PopStack(nganxep); // Bỏ dấu '(' khỏi stack
        }
        else
        {
            while (!IsEmpty(nganxep) && uutien(PeekStack(nganxep)) >= uutien(kytu))
            {
                hauto[j++] = PopStack(nganxep);
            }
            PushStack(nganxep,int(kytu));
        }
    }
    while (!IsEmpty(nganxep)) 
    {
        hauto[j++] = PopStack(nganxep);
    }
    hauto[j] = '\0';

    cout << "Bieu thuc hau to: " << hauto << endl;

    // Tính giá trị biểu thức hậu tố
    InitStack(nganxep, 100);
    for (int i = 0; hauto[i] != '\0'; i++) 
    {
        if (hauto[i] >= '0' && hauto[i] <= '9')
        {
            PushStack(nganxep, hauto[i] - '0');
        }
        else 
        {
            int so2 = PopStack(nganxep);
            int so1 = PopStack(nganxep);
            switch (hauto[i]) 
            {
            case '+': PushStack(nganxep, so1 + so2); break;
            case '-': PushStack(nganxep, so1 - so2); break;
            case '*': PushStack(nganxep, so1 * so2); break;
            case '/': PushStack(nganxep, so1 / so2); break;
            }
        }
    }
    cout << "Gia tri bieu thuc: " << PopStack(nganxep) << endl;
}

int main() 
{
    test1();
    test2();
    test3();
    test4();
    return 0;
}
